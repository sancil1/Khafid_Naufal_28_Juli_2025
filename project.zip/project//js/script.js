 document.getElementById("ver_Fzrvv").addEventListener('submit', function(event) {
         event.preventDefault();
    
         var username = document.getElementById('username').value;
         var password = document.getElementById('password').value;
         var errorMessage = document.getElementById('error-message');
    
      if (username === '' || password ==='') {
             errorMessage.textContent = 'ISI';
      } else if (username !== "kapit" || password !=='123') {
          errorMessage.textContent = 'salah'
      } else {
         errorMessage.textContent = ''
         alert('SUKSES.');
      }